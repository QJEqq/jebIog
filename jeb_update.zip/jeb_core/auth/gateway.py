import requests
import logging
from django.conf import settings
from django.core.cache import cache

logger = logging.getLogger(__name__)
BASE_URL = "https://gatewayapi.telegram.org"

def get_headers():
    token = settings.TELEGRAM_TOKEN
    return {
        "Authorization" : f"Bearer {token}",
        "Content-type" : "application/json"
    }

def sendVerificationMessage(phone_number):
    cooldown_key = f"tg_cooldown_{phone_number}"
    attemps_key = f"tg_attemps_{phone_number}"
    ban_key = f"tg_ban_{phone_number}"
    
    if cache.get(cooldown_key):
        logger.error(f'{phone_number} превышения запросов в минуту')
        return{
            'status' : "error" , 
            'message' : 'Повторная отправка возможна через 1 минуту.'
        }
    attemps = cache.get(attemps_key,0)
    if attemps >= 3: 
        cache.set(ban_key, True, timeout=86400)
        cache.delete(attemps_key)
        
        logger.error(f'Превышен лимит попыток. Номер {phone_number} заблокирован на 24 часа.')
        return {
            'status': "error",
            'message': 'Превышено максимальное количество попыток. Отправка заблокирована на 24 часа.'
        }
    url = f"{BASE_URL}/sendVerificationMessage"
    payload = {
        'phone_number' : str(phone_number),
        'code_length' : 4,
        "ttl" : 600
    }
    proxy_url = getattr(settings, 'TELEGRAM_PROXY', None)
    
    proxies = None
    if proxy_url:
        proxies = {
            "http": proxy_url,
            "https": proxy_url,
        }
    try:
        response = requests.post(url, json=payload, headers=get_headers(),proxies=proxies, timeout=2)
        if response.status_code == 200:
            res_data = response.json()
            if res_data.get('ok'):
                request_id = res_data.get("result", {}).get("request_id")
                if request_id:
                    cache.set(cooldown_key, True, timeout=57)
                    cache.set(attemps_key, attemps+1,timeout=3600)
                    return {
                        'status' : "success",
                        'request_id' : request_id
                    }
        return {"status": "error", "message": "Ошибка на стороне сервера отправки."}
    except Exception as e:
        logger.error(f"Сбой при отправке кода: {e}")
        return {"status": "error",
                "message": "Не удалось установить соединение с сервером."
                }
    
def checkVerificationStatus(request_id, user_code):
    url = f"{BASE_URL}/checkVerificationStatus"
    payload = {
        "request_id" : request_id,
        "code": user_code
    }
    proxy_url = getattr(settings, 'TELEGRAM_PROXY', None)
    
    proxies = None
    if proxy_url:
        proxies = {
            "http": proxy_url,
            "https": proxy_url,
        }
    try:
        response = requests.post(url, json=payload, headers=get_headers(),proxies=proxies,timeout=5)
        res_data = response.json()

        if res_data.get("ok"):
            status = res_data.get("result", {}).get("verification_status", {}).get("status")
            if status == 'code_valid':
                return True
        return False
    except Exception as e:
        logger.error(f'Сбой при проверке кода: {e}')
        return False